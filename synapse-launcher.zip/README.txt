Welocme to Synapse X remake!
There's something you need to know

You must download Microsoft Visual C++ Redistributable & .NET 8.0 to make Synapse X remake run properly.

Open these links below to download them.

https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170
https://dotnet.microsoft.com/en-us/download/dotnet/8.0
https://dotnet.microsoft.com/en-us/download/dotnet-framework/thank-you/net48-web-installer

Microsoft Visual C++ Redistributable is optional as this zip file already provides it, it is still recommended to download it.


If Synapse X remake does not run at all after restarting computer. Please install .NET 8.0 and click on repair. This is a problem with .NET

The Synapse X remake:
The website: https://getalacrity.github.io/getsynapse-remake/
The discord: https://discord.gg/3PwAy6Zy2D 